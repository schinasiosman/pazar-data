# Pazar data

Every night a GitHub Action downloads the published price lists of 15 Macedonian supermarket chains,
recognises the products, matches the same product across chains and publishes `prices.json` on GitHub Pages.
The Pazar app downloads that file once a day.

* `pipeline/fetch.py` — one small downloader per chain, plus product photos from Ramstore's online shop
* `pipeline/run.py` — recognise, group, attach photos and write `data/prices.json` (`python pipeline/run.py --offline` rebuilds from the saved lists)
* `pipeline/embed.py` — puts the newest `data/prices.json` into the app file as its built-in prices
* `data/photos.json`, `data/wiki_photos.json` — saved photo lists (shop photos; free Wikimedia Commons photos for fruit and vegetables)
* `site/index.html` — the page a shared-list link opens; it hands the code to the app
* `firebase-rules.json` — rules for the shared-list database
* If a chain's site is down, yesterday's list for that chain is kept; the report in `prices.json` says which.

## Switching it on (one time)

**Daily prices (GitHub, free)**
1. Create a GitHub account if you don't have one, then a new **public** repository named `pazar-data`.
2. Upload everything in this folder to it (Add file → Upload files; keep the folders).
3. Settings → Pages → Source: **GitHub Actions**.
4. Actions → *Daily prices* → **Run workflow**. After about 10 minutes the prices are at
   `https://<your-user>.github.io/pazar-data/prices.json`, and they refresh every night.

**Shared lists (Firebase, free)**
1. Go to console.firebase.google.com → Add project (name: `pazar`, Analytics off).
2. Build → Realtime Database → Create database → location *europe-west1* → Start in **locked mode**.
3. Rules tab → paste `firebase-rules.json` → Publish.
4. Copy the database address shown at the top (like `https://pazar-xxxx-default-rtdb.europe-west1.firebasedatabase.app`).

Send both addresses (your GitHub user name and the database address) and they go into the app.
